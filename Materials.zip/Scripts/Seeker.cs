﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Seeker : MonoBehaviour {
    public GameObject Alien;
    public GameObject Dog;
    public AudioSource dogsound;
    public AudioClip HappyPuppy;

    public Transform target;

    Rigidbody seeker;

    public float thrust;



    // Use this for initialization

    void Start()
    {

        seeker = GetComponent<Rigidbody>();

    }



    // Update is called once per frame
     

    void Update()
    {

        Vector3 targetDir = Vector3.Normalize(target.position - transform.position);

        seeker.AddForce(targetDir * thrust);
        if (Dog.transform.position == Alien.transform.position)
        { //is mover in same position as enemy?
          dogsound.PlayOneShot(HappyPuppy, 0.7F);

        }

    }

}